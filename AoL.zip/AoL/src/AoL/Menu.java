package AoL;

public class Menu {

}
