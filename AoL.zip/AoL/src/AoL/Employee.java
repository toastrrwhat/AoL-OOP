package AoL;

public class Employee {

}
